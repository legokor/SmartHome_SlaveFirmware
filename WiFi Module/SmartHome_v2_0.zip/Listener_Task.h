
#ifndef LISTENER_H
#define LISTENER_H
void ListenerTask(void* pvParameters)
{
	(MyUDP*)(pvParameters);
}

#endif // !LISTENER_H
