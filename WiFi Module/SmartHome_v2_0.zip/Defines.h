#ifndef DEFINES_H
#define DEFINES_H
//Device Constants
String Own_ID = "11002244";
String currID = "11111111";
//Wifi Default Settings

const char* Main_AP_ssid = "Chinese Bela";
const char* Main_AP_password = "paSSword";
char* Sec_AP_ssid = "STAP_";
const char* Sec_AP_password = "CHXYSW2:)64";

char* cmds[] = { "ACK", "DEN", "SND", "REC", "REQIP", "ERR" };

//WIFI server
int Config_Run_Time = 2000; //Defines the length of the client wait state when configuring
int Receive_Run_Time = 500; //Defines the length of the client wait state when only receiving from known clients
#endif