#include "Defines.h"


#ifndef PROGRAM_H
#define PROGRAM_H

#define CMD_NUM 5

/*
* The Program class hosts all the "global" functions and most of the variables
*/
class Program
{
public:
	static void ErrorLoop(/*MyUDP& udp*/)
	{
		while (1)
		{
			//udp.SendUDPPacket("ERR", udp.BROADCAsT, udp.GetPort());
		}
	}
	static char* ReadyOutput(float data[])
	{
		String Output = ("SND|" + Own_ID + "|" + String(data[0]) + "|" + String(data[1]) + "|" + String(data[2]) + "|" + String(data[3]) + "|" + String(data[4]) + "|" + String(data[5]) + "|" + "\r");
		char* temp = new char[Output.length() + 1];
		Output.toCharArray(temp, Output.length() + 1);
		return temp;
	}

	static bool StringCompare(const char* compare, const char* to)
	{
		if (strlen(compare) < strlen(to))
		{
			return false;
		}
		else{
			for (int i = 0; i < strlen(to); i++)
			{
				if (to[i] != compare[i])
					return false;
			}
			return true;
		}
	}

	/*
	* Processes an incoming massage and returns the position of the command it contains.
	* All commands are stored int the cmds global string table which size also strored in
	* the defined value of CMD_NUM.
	* Returns -1 if command not recognise.
	*/
	static int ProcessCommand(char* cmd_In, int len)
	{
		cmd_In[len] = '\0';
		Serial.print("Incoming command:");
		Serial.println(cmd_In);
		Serial.println("Massage length: " + String(len));

		for (int i = 0; i < CMD_NUM; i++)
		{
			Serial.println(cmds[i]);
			if (StringCompare(cmd_In, cmds[i]))
				return i;
		}
		return -1;
	}
};

#endif